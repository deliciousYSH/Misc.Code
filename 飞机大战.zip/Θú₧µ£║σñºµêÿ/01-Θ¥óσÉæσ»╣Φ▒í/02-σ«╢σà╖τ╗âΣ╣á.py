# 需求
#
# 房子(House) 有 户型、总面积 和 家具名称列表
# 新房子没有任何的家具
# 家具(HouseItem) 有 名字 和 占地面积，其中
# 席梦思(bed) 占地 4 平米
# 衣柜(chest) 占地 2 平米
# 餐桌(table) 占地 1.5 平米
# 将以上三件 家具 添加 到 房子 中
# 打印房子时，要求输出：户型、总面积、剩余面积、家具名称列表


class HouseItem:

    def __init__(self, name, area):
        self.name = name
        self.area = area

    def __str__(self):
        return "家具[%s]占地[%.2f]平米" % (self.name, self.area)


class House:

    def __init__(self, type, area):
        self.type = type
        self.area = area
        self.free_area = self.area
        # 列表,相当于其他语言里的集合(数组)
        # 线性数据结构(连续的索引)
        self.item_list = []

    def __str__(self):
        return "户型%s, 总面积%.2f, 剩余面积%.2f, 家具:[%s]" % (self.type, self.area, self.free_area, self.item_list)

    def add_item(self, item: HouseItem):
        # 添加家具到房子中
        if item.area > self.free_area:
            print("不能添加!剩余面积不足!")
            return

        # 添加
        self.item_list.append(item)
        # 计算
        self.free_area -= item.area


if __name__ == '__main__':
    # 1. 创建房子
    house = House("2s1t", 10)

    # 2. 创建家具
    item1 = HouseItem("席梦思", 4)
    item2 = HouseItem("衣柜", 2)
    item3 = HouseItem("餐桌", 2)

    # 3. 把家具放入房子
    house.add_item(item1)
    house.add_item(item2)
    house.add_item(item3)

    print(item1)
    print(house.item_list)
    # print(house)

