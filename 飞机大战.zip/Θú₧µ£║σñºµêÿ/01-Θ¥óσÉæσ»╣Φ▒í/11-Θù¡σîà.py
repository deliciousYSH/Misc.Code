
# y = kx + b


# def f(x, k, b):
#     return k * x + b
#
#
# print(f(2, 1, 2))


# def out_func(k, b):
#     # 在函数的内部在定义函数,并且内部的函数用到了外部函数作用域声明的变量
#     # 那么这个函数我们就称为闭包
#     def in_func(x):
#         # k = 100
#         nonlocal k
#         k += 1
#         print(k*x + b)
#     return in_func
#
#
# # 调用
# f1 = out_func(2, 3)
# f1(1)
# f1(2)
