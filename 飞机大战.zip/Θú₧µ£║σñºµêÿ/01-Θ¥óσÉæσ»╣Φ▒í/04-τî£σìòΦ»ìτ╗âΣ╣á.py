# 猜单词
# 1. 给定几个单词,随机选出一个作为玩家要猜的单词
# 2. 假如选出来是单词是hello, 根据单词的长度显示相同长度的-----
# 3. 然后根据玩家输入单词, 给出结果
# 4. 5次机会
import random


def test():
    l = [1, 2, 3, 4, 5]
    print(l[:5:2])


def guess_word():
    """猜单词"""
    words = ["hello", "abstract", "override", "class", "origin"]
    # 随机取出任意一个
    word = words[random.randint(0, len(words)-1)]
    # 给定相同长度的-来隐藏要猜的单词
    guess_w = "-" * len(word)
    print(guess_w)
    # 玩家玩的次数
    user_time = 5
    char_index = -1

    while True:
        # 接受用户输入的字符
        input_str = input("请输入:")
        # 判断用户输入的字符是否在要猜的单词中存在
        if input_str not in word:
            # 猜错了
            user_time -= 1
            print("猜错了!你还有%d次机会!" % user_time)
            if user_time == 0:
                print("你输了,游戏结束!")
                break
        else:
            print("你输入的是%s" % input_str)
            char_index = word.find(input_str, char_index + 1)
            print(char_index)

            # 替换
            gw = word[:char_index + 1] + guess_w[char_index+1:]
            print(gw)

            if '-' not in gw:
                break

    if user_time > 0:
        print("win")
    else:
        print("lose")
        print("你要猜的单词是%s" % word)


if __name__ == '__main__':
    guess_word()
    # test()