
# 函数的不定长参数


# def add(*args):
#     # print("形参列表是不定长参数的函数")
#     # print(args)
#     # print("-------------")
#     # print(type(args))
#     # print("-------------")
#     sum_num = 0
#     for value in args:
#         sum_num += value
#     print(sum_num)


# add(1)
# add(1, 2, 3)
# add(*[1, 2, 3])
#
#
# def per_info(**kwargs):
#     # print("-------")
#     print(type(kwargs))
#     print(kwargs)
#
#
# per_info(name='小红', age=18, sex='女')


# def test_arg(*args, **kwargs):
#     print("---args 元组中的参数 ---")
#     print(args)
#     print("---kwargs 字典中的参数 ---")
#     print(kwargs)
#
#
# test_arg(1, 2, 3, 4, 5, 19, name='小红', age=18, sex='女')


# 关键字参数
# def f1(name: str, age: int):
#     print("名字叫:%s, 年龄:%d" % (name, age))
#
#
# f1('小红', 18)
# f1(18, '小红')
# f1(age=18, name='小红')
# f1()


# 函数的多返回值处理
# 有几个函数的返回值,外部就应该定义几个变量来接收
# def f2(*args):
#     r1 = 0
#     r2 = 1
#     for value in args:
#         r1 += value
#         r2 *= value
#     return r1, r2, 0
#
#
# r1, r2, r3 = f2(1, 2, 3)
# print(r1)
# print(r2)


# 高阶函数
# def f3():
#     print("这是一个函数")
#     print(id(f3))
#
#
# f3()

# def f4(a, b, c):
#     return c(a) + c(b)
#
#
# print(f4(-2, 1, abs))



