

# x = 10
# 1. 局部作用域

# def f1():
#     a = 10
#     print("局部变量a的值:%d" % a)


# print(id(f1))
# f1()
# print(a)  # 访问不到a的引用

# if True:
#     a = 20
#     print("局部变量a的值:%d" % a)
#
# a += 1
# print(a)


# 2. 全局变量
# x = 10
#
#
# def f2():
#     # x = 20
#     # x += 10
#     # print(x)
#     global x
#     x = 20
#     print(x)
#
#
# print("调用函数之前全局变量x的值:%d" % x)
# f2()
# print("调用函数之后全局变量x的值:%d" % x)
