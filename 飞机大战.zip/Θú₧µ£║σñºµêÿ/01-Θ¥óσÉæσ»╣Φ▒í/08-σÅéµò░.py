

def f(x, y):
    # x.append(66)
    x += y
    # x = x + y

    # x = [5, 6, 7, 8]
    return x


# x = 1
# y = 2
# print(f(1, 2))

x = [1, 2, 3]
y = [4, 5, 6]

print("调用函数之前x的地址是:%s" % id(x))
x = f(x, y)
print("调用函数之后的x的地址是:%s" % id(x))
print(x)