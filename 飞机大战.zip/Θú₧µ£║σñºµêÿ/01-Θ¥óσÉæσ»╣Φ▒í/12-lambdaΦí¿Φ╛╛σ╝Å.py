# 1.链式编程
#   xxxx.xxx.xx.xx
#   属性的链式编程
# 2.函数式编程
#   lambda表达式(匿名函数)


def f(a, b):
    """
    计算两个数值型的求和
    :param a: int or float
    :param b: int or float
    :return: a and b sum
    """
    return a + b

# 上面是传统的函数, 如果传统的函数内只有单一的一行代码
# 这时候我们可以将这个函数转成匿名函数


print(f(1, 2))
x1 = lambda a, b: a + b
print(x1(1, 2))





