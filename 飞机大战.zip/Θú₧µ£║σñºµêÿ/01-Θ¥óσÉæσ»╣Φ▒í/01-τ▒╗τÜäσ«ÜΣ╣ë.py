

class Person:

    def __init__(self, name, sex):
        # self.count = 0
        # self.count += 1
        # print(self.count)
        # 魔法方法
        # print("创建了对象")
        # 定义类的特征 即属性
        self.name = name
        self.sex = sex
        # self.temp = ''

    # def __str__(self):
    #     pass
    #
    # def __new__(cls, *args, **kwargs):
    #     pass

    def eat(self):
        print('%s 吃东西' % self.name)

    def study(self):
        pass

    def play(self):
        pass

    def __str__(self):
        return "名字叫:%s 性别是:%s" % (self.name, self.sex)


def main():
    # 1.创建来对象
    # 类的定义:具有相同特征和行为的一类物体
    # 特征在python就是类的属性
    # 行为就是类中的方法
    p1 = Person("张三", "男")
    p2 = Person("李四", "女")

    # 2.给属性赋值
    # p1.name = "张三"
    # p2.name = "李四"

    # 3.调用方法
    p1.eat()
    p2.eat()

    print(p1)
    print(p2)


if __name__ == '__main__':
    # 函数的主入口
    main()
