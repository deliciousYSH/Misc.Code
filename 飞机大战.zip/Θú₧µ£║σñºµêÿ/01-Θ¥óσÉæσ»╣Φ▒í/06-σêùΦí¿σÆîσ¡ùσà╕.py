d1 = {
    'code': 200,
    'data': [
        {
            'name': '张三',
            'age': 18
         },
        {
            'name': '李四',
            'age': 22
        },
        {
            'name': '王五',
            'age': 19
        }
    ]
}

print(d1['code'])
print(d1.get('code', 1))


# player_hp = 100
# product_price = 100
#
#
# def response_from_server():
#     pass
#
#
# class Person:
#     pass



