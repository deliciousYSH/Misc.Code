# 导入包的原则
# 1. 先导入系统原生的 time random
# import time
# import random
# import math
# 2. 导入第三方的包
# import requests
# import numpy
# 3. 导入自定义的包

# 方式1------> 从某个包中导入所有的函数
# import Tools.DrawSprite
#
#
# Tools.DrawSprite.f1()


# 方式2------> 从某个包中的某个py文件中导入某个具体的函数
# from Tools.DrawSprite import f1
#
# f1()

# 方式3------> 从某个包中导入某个具体的py文件
# from Tools import DrawSprite
#
# DrawSprite.f1()

# 方式4(方式1改进)  起别名
# import Tools.DrawSprite as pd
# pd.DrawSprite.f1()

# 注意的地方:
# 某项目中包含2个py文件,一个是a.py 一个b.py
# 又假设a, b都用到了第三方的包requests
# 这时候就要考虑a 是否导入了b(或者b是否导入了a)
# 如果符合上述的情况,那么requests只需要导入一次即可(a或b)





