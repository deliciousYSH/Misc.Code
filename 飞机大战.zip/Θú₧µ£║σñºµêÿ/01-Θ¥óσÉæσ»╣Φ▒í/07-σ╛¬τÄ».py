# 可迭代对象
# 字符串, 列表是可迭代对象(iterable)

# for s in "hello word":
#     print(s)


# for x in range(1, 5, 2):
#     print(x)


# 使用for循环打印9 * 9乘法表
# for i in range(1, 10):
#     for j in range(1, i+1):
#         print('{}*{}={}\t'.format(i, j, i*j), end='')
#     # 换行
#     print("")


# import random
#
#
# # print(random.random())
# while True:
#     a = random.randint(1, 10)
#     print(a)
#     if a == 10:
#         break

#
# small = int(input("请输入一个小点的数:"))
# big = int(input("请输入一个大点的数:"))
# # 在small和big之间随机一个整数
# guess_num = random.randint(small, big)
# # 开始
# while True:
#     user_input = int(input("请输入数字:"))
#
#     if user_input > guess_num:
#         print("大了")
#     elif user_input < guess_num:
#         print("小了")
#     else:
#         print("猜对了 {}".format(guess_num))
#         break


# 可迭代对象
# from collections.abc import Iterable
#
# # 判断""是不是Iterable
# print(isinstance("", Iterable))
# print(isinstance((), Iterable))
# print(isinstance([], Iterable))
# print(isinstance(10, Iterable))
# print(isinstance(False, Iterable))
