import time

from game_sprite import *


class GameManager:

    def __init__(self):
        # 第一阶段
        # 游戏准备阶段
        # print("游戏准备中......")
        # 1. 设置游戏窗口
        self.window = pygame.display.set_mode(SCREEN_RECT.size)
        # 2. 设置帧率
        # fps -> 帧率越高,程序画面就越流畅(影响的是游戏循环的执行次数)
        # 60  -> 执行游戏循环需要约0.02s 每执行一次我们称执行了一帧
        # 2.1 创建时钟对象
        self.clock = pygame.time.Clock()
        # 3. 创建游戏精灵
        self.__create_sprite()
        # 4. 设置循环条件
        self.isRunning = True
        # 5. 定时器事件
        pygame.time.set_timer(CREATE_ENEMY_STONE, 1000)
        pygame.time.set_timer(CREATE_ENEMY_PLANE, randint(500, 2000))

    def __create_sprite(self):
        """
        创建游戏精灵
        :return: 无
        """
        # 1. 创建背景精灵
        bg = BackGround()
        bg2 = BackGround(isSwith=False)
        # 1.1 创建精灵组
        self.bg_group = pygame.sprite.Group(bg, bg2)

        # 2. 创建玩家精灵
        self.player = Player()
        self.player_group = pygame.sprite.Group(self.player)

        # 3. 创建外星人精灵
        self.alien_group = pygame.sprite.Group()

        # 4. 创建石头精灵
        self.stone_group = pygame.sprite.Group()

        # 5.创建爆炸
        self.bombs = pygame.sprite.Group()

    def create_stone(self):
        """
        创建陨石
        :return: 无
        """
        self.stone = Stone()
        self.stone_group.add(self.stone)

    def create_plane(self):
        """
        创建敌机
        :return: 无
        """
        self.alien = Alien()
        self.alien_group.add(self.alien)

    def create_bomb(self, x, y):

        self.bomb = Bomb(x, y)
        self.bombs.add(self.bomb)

    def gaming(self):
        # 第二阶段
        # 游戏中阶段
        # 1. 初始化pygame中的内部模块
        pygame.init()

        while self.isRunning:
            # print("游戏中.......")
            # 2. 设置帧率
            self.clock.tick(60)
            # 3. 事件监听
            self.__event()
            # 4. 碰撞检测
            self.__collided()
            # 5. 更新精灵
            self.__update_sprites()
            # 6. 更新窗口
            pygame.display.update()
        GameManager.end()

    def __event(self):
        """
        事件检测
        :return: 无
        """
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # 说明用户点了窗口上面的x
                self.isRunning = False
            elif event.type == CREATE_ENEMY_STONE:
                self.create_stone()
            elif event.type == CREATE_ENEMY_PLANE:
                self.create_plane()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    self.player.fire()

            # elif event.type == pygame.KEYDOWN:
            #     if event.key == pygame.K_LEFT:
            #         print("按下了 ⬅")
            #         self.player.speedx = -8
            #         # self.player.left_move()
            #     if event.key == pygame.K_RIGHT:
            #         print("按下了 ➡")
            #         self.player.speedx = 8

    def __collided(self):
        """
        碰撞检测
        :return: 无
        """
        lst = pygame.sprite.groupcollide(self.alien_group, self.player.bullet_group, True, True)
        if len(lst.keys()) != 0:
            x_1 = list(lst.keys())[0].rect.x
            y_1 = list(lst.keys())[0].rect.y
            print(x_1, y_1)
            self.create_bomb(x_1, y_1)
            # for bomb in self.bombs:
            #     # 爆炸对象设置爆炸位置
            #     bomb.set_pos(x_1, y_1)

        if pygame.sprite.spritecollideany(self.player,  self.alien_group) or pygame.sprite.spritecollideany(self.player, self.stone_group):
            leng = len(self.player.life_group)
            # print(leng)
            if leng == 1:
                self.isRunning = False
            else:
                for i in iter(self.player.life_group):
                    if leng == 1:
                        self.player.life_group.remove(i)
                    else:
                        leng -= 1
                self.alien_group.empty()
                self.player.bullet_group.empty()
                self.stone_group.empty()


    def __update_sprites(self):
        """
        更新精灵
        :return: 无
        """
        # 先更新在绘制
        self.bg_group.update()
        self.bg_group.draw(self.window)

        self.player_group.update()
        self.player_group.draw(self.window)

        # 更新玩家生命
        self.player.life_group.update()
        self.player.life_group.draw(self.window)

        # 更新子弹
        self.player.bullet_group.update()
        self.player.bullet_group.draw(self.window)

        # 更新外星人
        self.alien_group.update()
        self.alien_group.draw(self.window)

        # 更新石头
        self.stone_group.update()
        self.stone_group.draw(self.window)

        # 更新爆炸
        self.bombs.update()
        self.bombs.draw(self.window)



    @classmethod
    def end(cls):
        # 第三阶段
        # 游戏结束
        # 卸载加载的内部模块
        pygame.quit()
        print("游戏结束!")


if __name__ == '__main__':
    # 游戏入口
    GameManager().gaming()
