

def f1():
    print("这是DrawSprite.py文件下面的一个函数f1()")


def f2():
    print("这是DrawSprite.py文件下面的一个函数f2()")