

def f1():
    print("这是package_2.py文件下面的一个函数f1()")


def f2():
    print("这是package_2.py文件下面的一个函数f2()")