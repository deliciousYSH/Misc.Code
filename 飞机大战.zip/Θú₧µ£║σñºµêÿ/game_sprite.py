from game_constant import *
from random import *


class BaseSprite(pygame.sprite.Sprite):
    """
    精灵基类(父类)
    """
    def __init__(self, img_src, speed=1):
        super(BaseSprite, self).__init__()
        # 根据路径加载图片到内存中
        self.image = pygame.image.load(img_src)

        # 获取图像的尺寸
        self.rect = self.image.get_rect()
        self.speed = speed

    def update(self):
        super(BaseSprite, self).update()
        # __mro__
        # super().update()
        # 默认所有的派生类都是从上向下进行移动的
        self.rect.y += self.speed


class BackGround(BaseSprite):
    """
    通过基类派生出来的背景精灵(派生类/子类)
    """
    def __init__(self, isSwith=True):
        super(BackGround, self).__init__(IMG_BG_SRC)

        # 设置背景的初始位置
        if not isSwith:
            self.rect.y = -self.rect.height

    def update(self):
        # super().update()
        super(BackGround, self).update()

        if self.rect.y >= SCREEN_RECT.height:
            # 能来到这里说明背景将要移出屏幕
            self.rect.y = -self.rect.height


class Player(BaseSprite):

    def __init__(self):
        super().__init__(IMG_PL_SRC)

        # 修改飞机的原始尺寸
        self.image = pygame.transform.scale(self.image, (50, 38))
        # 重新获取飞机的rect
        self.rect = self.image.get_rect()

        # 初始位置
        self.rect.centerx = SCREEN_RECT.width / 2
        self.rect.bottom = SCREEN_RECT.height - 15

        # 设置水平初始和垂直初始速度
        self.speedx = 0
        self.speedy = 0

        # 生命
        # 初始化生命精灵

        life1 = PlayerLife(5, 5)
        life2 = PlayerLife(30, 5)
        life3 = PlayerLife(55, 5)
        self.life_group = pygame.sprite.Group(life1)
        self.life_group.add(life2)
        self.life_group.add(life3)

        # 初始化子弹精灵组
        self.bullet_group = pygame.sprite.Group()

    def update(self):
        # 重置水平速度
        self.speedx = 0

        # 获取按键按下
        key = pygame.key.get_pressed()
        if key[pygame.K_LEFT]:
            self.speedx = -8
        if key[pygame.K_RIGHT]:
            self.speedx = 8

        self.rect.x += self.speedx

        # 限制飞机移动的区域
        if self.rect.x < 0:
            self.rect.x = 0
        elif self.rect.x > SCREEN_RECT.width - self.rect.width:
            # self.rect.right > SCREEN_RECT.width
            self.rect.right = SCREEN_RECT.width

    def fire(self):
        """
        开火
        :return:
        """
        b = Bullet()

        # 设置子弹的位置
        b.rect.centerx = self.rect.centerx
        b.rect.bottom = self.rect.top - 5
        self.bullet_group.add(b)


class PlayerLife(BaseSprite):
    def __init__(self, x, y):
        super(PlayerLife, self).__init__(IMG_PL_SRC)

        # 修改尺寸
        self.image = pygame.transform.scale(self.image, (25, 19))
        self.rect = self.image.get_rect()

        # 设置位置
        self.rect.x = x
        self.rect.y = y

    def update(self):
        pass


class Bullet(BaseSprite):

    def __init__(self):
        super().__init__(IMG_BULLET_SRC, speed=-10)

    def update(self):
        super().update()

        # 处理飞出屏幕的子弹
        if self.rect.bottom < 0:
            self.kill()

    def __del__(self):
        print("子弹消失了!")


class Alien(BaseSprite):

    def __init__(self):
        super().__init__(IMG_WX_SRC)

        # 修改外星人的原始尺寸
        self.image = pygame.transform.scale(self.image, (50, 38))
        # 重新获取外星人的rect
        self.rect = self.image.get_rect()

        # 初始位置
        self.rect.centerx = uniform(0, SCREEN_RECT.width)
        self.rect.bottom = 15

        # 设置水平初始和垂直初始速度
        self.speedx = randrange(-1, 3, 2) * 15



        # 初始化外星人精灵组
        #self.alien_group = pygame.sprite.Group()

    def update(self):

        #self.rect.x += uniform(-4, 4) * self.speedx
        self.rect.y += 2
        self.rect.x += self.speedx
        if self.rect.x > SCREEN_RECT.width - self.rect.width:
            # self.rect.right > SCREEN_RECT.width
            self.rect.right = SCREEN_RECT.width
            self.speedx = -self.speedx


        # 限制外星人移动的区域
        elif self.rect.x < 0:
            self.rect.x = 0
            self.speedx = -self.speedx

        if self.rect.y > SCREEN_RECT.bottom:
            self.remove()


class Stone(BaseSprite):

    def __init__(self):
        stone_list = [IMG_ST1_SRC, IMG_ST2_SRC, IMG_ST3_SRC, IMG_ST4_SRC, IMG_ST5_SRC, IMG_ST6_SRC, IMG_ST7_SRC]
        super().__init__(stone_list[randint(0, 6)])

        # 修改石头的原始尺寸
        self.image = pygame.transform.scale(self.image, (50, 38))
        # 重新获取石头的rect
        self.rect = self.image.get_rect()

        # 初始位置
        self.rect.centerx = uniform(0, SCREEN_RECT.width)
        self.rect.bottom = 15

        # 设置水平初始和垂直初始速度
        self.speedx = 0
        self.speedy = 5

        # 初始化外星人精灵组
        #self.alien_group = pygame.sprite.Group()

    def update(self):

        #self.rect.x += uniform(-4, 4) * self.speedx
        self.rect.y += self.speedy

        if self.rect.y > SCREEN_RECT.bottom:
            self.remove()


class Bomb(BaseSprite):
    # 初始化爆炸
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        # 加载爆炸资源
        self.images = [pygame.image.load(REGULAR_FILE + str(v) + ".png") for v in range(0, 9)]
        # 设置当前爆炸播放索引
        self.index = 0

        self.image = self.images[self.index]
        self.rect = self.image.get_rect()
        self.image = pygame.transform.scale(self.image, (50, 38))

        self.rect.x = x
        self.rect.y = y



    # 绘制爆炸
    def update(self):
        if self.index >= len(self.images):
            self.kill()
        else:
            self.image = self.images[self.index]
            self.index += 1












