import os
import pygame


# 游戏屏幕尺寸
SCREEN_RECT = pygame.Rect(0, 0, 480, 600)

# 用户自定义事件id
CREATE_ENEMY_STONE = pygame.USEREVENT  # 24
CREATE_ENEMY_PLANE = pygame.USEREVENT + 1

# 获取项目所在的路径
PROJECT_SRC = os.path.dirname(__file__)
# print(type(PROJECT_SRC))

# 背景精灵路径
IMG_BG_SRC = os.path.join(PROJECT_SRC, "img", "starfield.png")
# 玩家精灵路径
IMG_PL_SRC = os.path.join(PROJECT_SRC, "img", "playerShip1_orange.png")
# 玩家子弹精灵路径
IMG_BULLET_SRC = os.path.join(PROJECT_SRC, "img", "laserRed16.png")
# 外星人精灵路径
IMG_WX_SRC = os.path.join(PROJECT_SRC, "img", "p1_jump.png")
# 石头精灵路径
IMG_ST1_SRC = os.path.join(PROJECT_SRC, "img", "meteorBrown_big1.png")
IMG_ST2_SRC = os.path.join(PROJECT_SRC, "img", "meteorBrown_big2.png")
IMG_ST3_SRC = os.path.join(PROJECT_SRC, "img", "meteorBrown_med1.png")
IMG_ST4_SRC = os.path.join(PROJECT_SRC, "img", "meteorBrown_med3.png")
IMG_ST5_SRC = os.path.join(PROJECT_SRC, "img", "meteorBrown_small1.png")
IMG_ST6_SRC = os.path.join(PROJECT_SRC, "img", "meteorBrown_small2.png")
IMG_ST7_SRC = os.path.join(PROJECT_SRC, "img", "meteorBrown_tiny1.png")
# 爆炸效果
REGULAR_FILE = "img/regularExplosion0"


