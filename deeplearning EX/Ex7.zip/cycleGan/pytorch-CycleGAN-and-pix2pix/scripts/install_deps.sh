set -ex
pip install visdom
pip install dominate
